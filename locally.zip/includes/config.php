<?php

/**
 * =====================================
 * LOCALLY
 * Configuración General
 * =====================================
 */

define("APP_NAME", "Locally");

define("APP_URL", "https://locally.cr");

define("APP_EMAIL", "noreply@locally.cr");

define("TOKEN_EXPIRATION_MINUTES", 30);

define("APP_LOGO", "https://locally.cr/img/blackLogo.png");

date_default_timezone_set("America/Costa_Rica");
